jQuery(document).ready(function ($) {
    $('.mc-color-input').wpColorPicker();
});