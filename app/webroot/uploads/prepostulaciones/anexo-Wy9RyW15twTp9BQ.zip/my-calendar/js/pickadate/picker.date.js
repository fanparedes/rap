/*!
 * Date picker for pickadate.js v3.4.0
 * http://amsul.github.io/pickadate.js/date.htm
 */
!function (a) {
    "function" == typeof define && define.amd ? define(["picker", "jquery"], a) : a(Picker, jQuery)
}(function (a, b) {
    function c(a, b) {
        var c = this, d = a.$node[0].value, e = a.$node.data("value"), f = e || d, g = e ? b.formatSubmit : b.format, h = function () {
            return "rtl" === getComputedStyle(a.$root[0]).direction
        };
        c.settings = b, c.$node = a.$node, c.queue = {
            min: "measure create",
            max: "measure create",
            now: "now create",
            select: "parse create validate",
            highlight: "parse navigate create validate",
            view: "parse create validate viewset",
            disable: "deactivate",
            enable: "activate"
        }, c.item = {}, c.item.disable = (b.disable || []).slice(0), c.item.enable = -function (a) {
            return a[0] === !0 ? a.shift() : -1
        }(c.item.disable), c.set("min", b.min).set("max", b.max).set("now"), f ? c.set("select", f, {
            format: g,
            fromValue: !!d
        }) : c.set("select", null).set("highlight", c.item.now), c.key = {
            40: 7, 38: -7, 39: function () {
                return h() ? -1 : 1
            }, 37: function () {
                return h() ? 1 : -1
            }, go: function (a) {
                var b = c.item.highlight, d = new Date(b.year, b.month, b.date + a);
                c.set("highlight", [d.getFullYear(), d.getMonth(), d.getDate()], {interval: a}), this.render()
            }
        }, a.on("render", function () {
            a.$root.find("." + b.klass.selectMonth).on("change", function () {
                var c = this.value;
                c && (a.set("highlight", [a.get("view").year, c, a.get("highlight").date]), a.$root.find("." + b.klass.selectMonth).trigger("focus"))
            }), a.$root.find("." + b.klass.selectYear).on("change", function () {
                var c = this.value;
                c && (a.set("highlight", [c, a.get("view").month, a.get("highlight").date]), a.$root.find("." + b.klass.selectYear).trigger("focus"))
            })
        }).on("open", function () {
            a.$root.find("button, select").attr("disabled", !1)
        }).on("close", function () {
            a.$root.find("button, select").attr("disabled", !0)
        })
    }

    var d = 7, e = 6, f = a._;
    c.prototype.set = function (a, b, c) {
        var d = this, e = d.item;
        return null === b ? (e[a] = b, d) : (e["enable" == a ? "disable" : "flip" == a ? "enable" : a] = d.queue[a].split(" ").map(function (e) {
            return b = d[e](a, b, c)
        }).pop(), "select" == a ? d.set("highlight", e.select, c) : "highlight" == a ? d.set("view", e.highlight, c) : a.match(/^(flip|min|max|disable|enable)$/) && (e.select && d.disabled(e.select) && d.set("select", e.select, c), e.highlight && d.disabled(e.highlight) && d.set("highlight", e.highlight, c)), d)
    }, c.prototype.get = function (a) {
        return this.item[a]
    }, c.prototype.create = function (a, c, d) {
        var e, g = this;
        return c = void 0 === c ? a : c, c == -1 / 0 || 1 / 0 == c ? e = c : b.isPlainObject(c) && f.isInteger(c.pick) ? c = c.obj : b.isArray(c) ? (c = new Date(c[0], c[1], c[2]), c = f.isDate(c) ? c : g.create().obj) : c = f.isInteger(c) || f.isDate(c) ? g.normalize(new Date(c), d) : g.now(a, c, d), {
            year: e || c.getFullYear(),
            month: e || c.getMonth(),
            date: e || c.getDate(),
            day: e || c.getDay(),
            obj: e || c,
            pick: e || c.getTime()
        }
    }, c.prototype.createRange = function (a, c) {
        var d = this, e = function (a) {
            return a === !0 || b.isArray(a) || f.isDate(a) ? d.create(a) : a
        };
        return f.isInteger(a) || (a = e(a)), f.isInteger(c) || (c = e(c)), f.isInteger(a) && b.isPlainObject(c) ? a = [c.year, c.month, c.date + a] : f.isInteger(c) && b.isPlainObject(a) && (c = [a.year, a.month, a.date + c]), {
            from: e(a),
            to: e(c)
        }
    }, c.prototype.withinRange = function (a, b) {
        return a = this.createRange(a.from, a.to), b.pick >= a.from.pick && b.pick <= a.to.pick
    }, c.prototype.overlapRanges = function (a, b) {
        var c = this;
        return a = c.createRange(a.from, a.to), b = c.createRange(b.from, b.to), c.withinRange(a, b.from) || c.withinRange(a, b.to) || c.withinRange(b, a.from) || c.withinRange(b, a.to)
    }, c.prototype.now = function (a, b, c) {
        return b = new Date, c && c.rel && b.setDate(b.getDate() + c.rel), this.normalize(b, c)
    }, c.prototype.navigate = function (a, c, d) {
        var e, f, g, h, i = b.isArray(c), j = b.isPlainObject(c), k = this.item.view;
        if (i || j) {
            for (j ? (f = c.year, g = c.month, h = c.date) : (f = +c[0], g = +c[1], h = +c[2]), d && d.nav && k && k.month !== g && (f = k.year, g = k.month), e = new Date(f, g + (d && d.nav ? d.nav : 0), 1), f = e.getFullYear(), g = e.getMonth(); new Date(f, g, h).getMonth() !== g;)h -= 1;
            c = [f, g, h]
        }
        return c
    }, c.prototype.normalize = function (a) {
        return a.setHours(0, 0, 0, 0), a
    }, c.prototype.measure = function (a, b) {
        var c = this;
        return b ? f.isInteger(b) && (b = c.now(a, b, {rel: b})) : b = "min" == a ? -1 / 0 : 1 / 0, b
    }, c.prototype.viewset = function (a, b) {
        return this.create([b.year, b.month, 1])
    }, c.prototype.validate = function (a, c, d) {
        var e, g, h, i, j = this, k = c, l = d && d.interval ? d.interval : 1, m = -1 === j.item.enable, n = j.item.min, o = j.item.max, p = m && j.item.disable.filter(function (a) {
                if (b.isArray(a)) {
                    var d = j.create(a).pick;
                    d < c.pick ? e = !0 : d > c.pick && (g = !0)
                }
                return f.isInteger(a)
            }).length;
        if ((!d || !d.nav) && (!m && j.disabled(c) || m && j.disabled(c) && (p || e || g) || !m && (c.pick <= n.pick || c.pick >= o.pick)))for (m && !p && (!g && l > 0 || !e && 0 > l) && (l *= -1); j.disabled(c) && (Math.abs(l) > 1 && (c.month < k.month || c.month > k.month) && (c = k, l = l > 0 ? 1 : -1), c.pick <= n.pick ? (h = !0, l = 1, c = j.create([n.year, n.month, n.date - 1])) : c.pick >= o.pick && (i = !0, l = -1, c = j.create([o.year, o.month, o.date + 1])), !h || !i);)c = j.create([c.year, c.month, c.date + l]);
        return c
    }, c.prototype.disabled = function (a) {
        var c = this, d = c.item.disable.filter(function (d) {
            return f.isInteger(d) ? a.day === (c.settings.firstDay ? d : d - 1) % 7 : b.isArray(d) || f.isDate(d) ? a.pick === c.create(d).pick : b.isPlainObject(d) ? c.withinRange(d, a) : void 0
        });
        return d = d.length && !d.filter(function (a) {
            return b.isArray(a) && "inverted" == a[3] || b.isPlainObject(a) && a.inverted
        }).length, -1 === c.item.enable ? !d : d || a.pick < c.item.min.pick || a.pick > c.item.max.pick
    }, c.prototype.parse = function (a, c, d) {
        var e, g = this, h = {};
        return !c || f.isInteger(c) || b.isArray(c) || f.isDate(c) || b.isPlainObject(c) && f.isInteger(c.pick) ? c : (d && d.format || (d = d || {}, d.format = g.settings.format), e = "string" != typeof c || d.fromValue ? 0 : 1, g.formats.toArray(d.format).map(function (a) {
            var b = g.formats[a], d = b ? f.trigger(b, g, [c, h]) : a.replace(/^!/, "").length;
            b && (h[a] = c.substr(0, d)), c = c.substr(d)
        }), [h.yyyy || h.yy, +(h.mm || h.m) - e, h.dd || h.d])
    }, c.prototype.formats = function () {
        function a(a, b, c) {
            var d = a.match(/\w+/)[0];
            return c.mm || c.m || (c.m = b.indexOf(d)), d.length
        }

        function b(a) {
            return a.match(/\w+/)[0].length
        }

        return {
            d: function (a, b) {
                return a ? f.digits(a) : b.date
            }, dd: function (a, b) {
                return a ? 2 : f.lead(b.date)
            }, ddd: function (a, c) {
                return a ? b(a) : this.settings.weekdaysShort[c.day]
            }, dddd: function (a, c) {
                return a ? b(a) : this.settings.weekdaysFull[c.day]
            }, m: function (a, b) {
                return a ? f.digits(a) : b.month + 1
            }, mm: function (a, b) {
                return a ? 2 : f.lead(b.month + 1)
            }, mmm: function (b, c) {
                var d = this.settings.monthsShort;
                return b ? a(b, d, c) : d[c.month]
            }, mmmm: function (b, c) {
                var d = this.settings.monthsFull;
                return b ? a(b, d, c) : d[c.month]
            }, yy: function (a, b) {
                return a ? 2 : ("" + b.year).slice(2)
            }, yyyy: function (a, b) {
                return a ? 4 : b.year
            }, toArray: function (a) {
                return a.split(/(d{1,4}|m{1,4}|y{4}|yy|!.)/g)
            }, toString: function (a, b) {
                var c = this;
                return c.formats.toArray(a).map(function (a) {
                    return f.trigger(c.formats[a], c, [0, b]) || a.replace(/^!/, "")
                }).join("")
            }
        }
    }(), c.prototype.isDateExact = function (a, c) {
        var d = this;
        return f.isInteger(a) && f.isInteger(c) || "boolean" == typeof a && "boolean" == typeof c ? a === c : (f.isDate(a) || b.isArray(a)) && (f.isDate(c) || b.isArray(c)) ? d.create(a).pick === d.create(c).pick : b.isPlainObject(a) && b.isPlainObject(c) ? d.isDateExact(a.from, c.from) && d.isDateExact(a.to, c.to) : !1
    }, c.prototype.isDateOverlap = function (a, c) {
        var d = this;
        return f.isInteger(a) && (f.isDate(c) || b.isArray(c)) ? a === d.create(c).day + 1 : f.isInteger(c) && (f.isDate(a) || b.isArray(a)) ? c === d.create(a).day + 1 : b.isPlainObject(a) && b.isPlainObject(c) ? d.overlapRanges(a, c) : !1
    }, c.prototype.flipEnable = function (a) {
        var b = this.item;
        b.enable = a || (-1 == b.enable ? 1 : -1)
    }, c.prototype.deactivate = function (a, c) {
        var d = this, e = d.item.disable.slice(0);
        return "flip" == c ? d.flipEnable() : c === !1 ? (d.flipEnable(1), e = []) : c === !0 ? (d.flipEnable(-1), e = []) : c.map(function (a) {
            for (var c, g = 0; g < e.length; g += 1)if (d.isDateExact(a, e[g])) {
                c = !0;
                break
            }
            c || (f.isInteger(a) || f.isDate(a) || b.isArray(a) || b.isPlainObject(a) && a.from && a.to) && e.push(a)
        }), e
    }, c.prototype.activate = function (a, c) {
        var d = this, e = d.item.disable, g = e.length;
        return "flip" == c ? d.flipEnable() : c === !0 ? (d.flipEnable(1), e = []) : c === !1 ? (d.flipEnable(-1), e = []) : c.map(function (a) {
            var c, h, i, j;
            for (i = 0; g > i; i += 1) {
                if (h = e[i], d.isDateExact(h, a)) {
                    c = e[i] = null, j = !0;
                    break
                }
                if (d.isDateOverlap(h, a)) {
                    b.isPlainObject(a) ? (a.inverted = !0, c = a) : b.isArray(a) ? (c = a, c[3] || c.push("inverted")) : f.isDate(a) && (c = [a.getFullYear(), a.getMonth(), a.getDate(), "inverted"]);
                    break
                }
            }
            if (c)for (i = 0; g > i; i += 1)if (d.isDateExact(e[i], a)) {
                e[i] = null;
                break
            }
            if (j)for (i = 0; g > i; i += 1)if (d.isDateOverlap(e[i], a)) {
                e[i] = null;
                break
            }
            c && e.push(c)
        }), e.filter(function (a) {
            return null != a
        })
    }, c.prototype.nodes = function (a) {
        var b = this, c = b.settings, g = b.item, h = g.now, i = g.select, j = g.highlight, k = g.view, l = g.disable, m = g.min, n = g.max, o = function (a) {
            return c.firstDay && a.push(a.shift()), f.node("thead", f.node("tr", f.group({
                min: 0,
                max: d - 1,
                i: 1,
                node: "th",
                item: function (b) {
                    return [a[b], c.klass.weekdays]
                }
            })))
        }((c.showWeekdaysFull ? c.weekdaysFull : c.weekdaysShort).slice(0)), p = function (a) {
            return f.node("div", " ", c.klass["nav" + (a ? "Next" : "Prev")] + (a && k.year >= n.year && k.month >= n.month || !a && k.year <= m.year && k.month <= m.month ? " " + c.klass.navDisabled : ""), "data-nav=" + (a || -1))
        }, q = function (b) {
            return c.selectMonths ? f.node("select", f.group({
                min: 0,
                max: 11,
                i: 1,
                node: "option",
                item: function (a) {
                    return [b[a], 0, "value=" + a + (k.month == a ? " selected" : "") + (k.year == m.year && a < m.month || k.year == n.year && a > n.month ? " disabled" : "")]
                }
            }), c.klass.selectMonth, a ? "" : "disabled") : f.node("div", b[k.month], c.klass.month)
        }, r = function () {
            var b = k.year, d = c.selectYears === !0 ? 5 : ~~(c.selectYears / 2);
            if (d) {
                var e = m.year, g = n.year, h = b - d, i = b + d;
                if (e > h && (i += e - h, h = e), i > g) {
                    var j = h - e, l = i - g;
                    h -= j > l ? l : j, i = g
                }
                return f.node("select", f.group({
                    min: h, max: i, i: 1, node: "option", item: function (a) {
                        return [a, 0, "value=" + a + (b == a ? " selected" : "")]
                    }
                }), c.klass.selectYear, a ? "" : "disabled")
            }
            return f.node("div", b, c.klass.year)
        };
        return f.node("div", p() + p(1) + q(c.showMonthsShort ? c.monthsShort : c.monthsFull) + r(), c.klass.header) + f.node("table", o + f.node("tbody", f.group({
            min: 0,
            max: e - 1,
            i: 1,
            node: "tr",
            item: function (a) {
                var e = c.firstDay && 0 === b.create([k.year, k.month, 1]).day ? -7 : 0;
                return [f.group({
                    min: d * a - k.day + e + 1, max: function () {
                        return this.min + d - 1
                    }, i: 1, node: "td", item: function (a) {
                        a = b.create([k.year, k.month, a + (c.firstDay ? 1 : 0)]);
                        var d = i && i.pick == a.pick, e = j && j.pick == a.pick, g = l && b.disabled(a) || a.pick < m.pick || a.pick > n.pick;
                        return [f.node("div", a.date, function (b) {
                            return b.push(k.month == a.month ? c.klass.infocus : c.klass.outfocus), h.pick == a.pick && b.push(c.klass.now), d && b.push(c.klass.selected), e && b.push(c.klass.highlighted), g && b.push(c.klass.disabled), b.join(" ")
                        }([c.klass.day]), "data-pick=" + a.pick + " " + f.ariaAttr({
                            role: "button",
                            controls: b.$node[0].id,
                            checked: d && b.$node.val() === f.trigger(b.formats.toString, b, [c.format, a]) ? !0 : null,
                            activedescendant: e ? !0 : null,
                            disabled: g ? !0 : null
                        }))]
                    }
                })]
            }
        })), c.klass.table) + f.node("div", f.node("button", c.today, c.klass.buttonToday, "type=button data-pick=" + h.pick + (a ? "" : " disabled")) + f.node("button", c.clear, c.klass.buttonClear, "type=button data-clear=1" + (a ? "" : " disabled")), c.klass.footer)
    }, c.defaults = function (a) {
        return {
            monthsFull: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            monthsShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            weekdaysFull: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            weekdaysShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            today: "Today",
            clear: "Clear",
            format: "d mmmm, yyyy",
            klass: {
                table: a + "table",
                header: a + "header",
                navPrev: a + "nav--prev",
                navNext: a + "nav--next",
                navDisabled: a + "nav--disabled",
                month: a + "month",
                year: a + "year",
                selectMonth: a + "select--month",
                selectYear: a + "select--year",
                weekdays: a + "weekday",
                day: a + "day",
                disabled: a + "day--disabled",
                selected: a + "day--selected",
                highlighted: a + "day--highlighted",
                now: a + "day--today",
                infocus: a + "day--infocus",
                outfocus: a + "day--outfocus",
                footer: a + "footer",
                buttonClear: a + "button--clear",
                buttonToday: a + "button--today"
            }
        }
    }(a.klasses().picker + "__"), a.extend("pickadate", c)
});